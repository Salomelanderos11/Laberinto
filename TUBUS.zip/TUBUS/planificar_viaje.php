<?php
/*
 * planificar_viaje.php
 * --------------------
 * Recibe: origen (GPS) + destino (geocodificado)
 * Devuelve: plan de viaje con 1, 2 o 3 rutas + transbordos
 */
require 'Conexion.php';
header('Content-Type: application/json');

$origLat = isset($_GET['orig_lat']) ? (float)$_GET['orig_lat'] : 0;
$origLng = isset($_GET['orig_lng']) ? (float)$_GET['orig_lng'] : 0;
$destLat = isset($_GET['dest_lat']) ? (float)$_GET['dest_lat'] : 0;
$destLng = isset($_GET['dest_lng']) ? (float)$_GET['dest_lng'] : 0;
$radio   = isset($_GET['radio'])    ? (int)$_GET['radio']      : 500;

if (!$origLat || !$destLat) {
    echo json_encode(['error' => 'Coordenadas inválidas.']);
    exit;
}

/* ──────────────────────────────────────────
   HELPERS GEOMÉTRICOS
────────────────────────────────────────── */
function distPuntoSegmento($lat, $lng, $lat1, $lng1, $lat2, $lng2) {
    $m   = deg2rad(($lat1 + $lat2) / 2);
    $sLt = 111320;
    $sLn = 111320 * cos($m);
    $px  = ($lng  - $lng1) * $sLn;  $py = ($lat  - $lat1) * $sLt;
    $dx  = ($lng2 - $lng1) * $sLn;  $dy = ($lat2 - $lat1) * $sLt;
    $l2  = $dx * $dx + $dy * $dy;
    if ($l2 == 0) return sqrt($px * $px + $py * $py);
    $t = max(0, min(1, ($px * $dx + $py * $dy) / $l2));
    return sqrt(($px - $t * $dx) ** 2 + ($py - $t * $dy) ** 2);
}

function distMinRuta($lat, $lng, $coords) {
    $min     = PHP_FLOAT_MAX;
    $bestIdx = 0;
    $n       = count($coords);
    for ($i = 0; $i < $n - 1; $i++) {
        $d = distPuntoSegmento(
            $lat, $lng,
            $coords[$i]['lat'],   $coords[$i]['lng'],
            $coords[$i+1]['lat'], $coords[$i+1]['lng']
        );
        if ($d < $min) { $min = $d; $bestIdx = $i; }
    }
    return ['dist' => $min, 'idx' => $bestIdx];
}

function parsearWKT($wkt) {
    $limpio = str_replace(['LINESTRING(', ')'], '', $wkt);
    $out    = [];
    foreach (explode(',', $limpio) as $p) {
        $xy = explode(' ', trim($p));
        if (count($xy) >= 2)
            $out[] = ['lat' => (float)$xy[1], 'lng' => (float)$xy[0]];
    }
    return $out;
}

/* ──────────────────────────────────────────
   CARGAR RUTAS CON GEOMETRÍA
────────────────────────────────────────── */
$sql = "SELECT tr.nombre, ST_AsText(tr.camino) AS wkt,
               r.id, r.descripcion, r.conductor, r.paradas
        FROM trazado_rutas tr
        LEFT JOIN rutas r ON r.nombre_ruta = tr.nombre";

$res   = $conn->query($sql);
$rutas = [];

while ($f = $res->fetch_assoc()) {
    $coords = parsearWKT($f['wkt']);
    if (count($coords) < 2) continue;

    $o = distMinRuta($origLat, $origLng, $coords);
    $d = distMinRuta($destLat, $destLng, $coords);

    $rutas[] = [
        'nombre'      => $f['nombre'],
        'id'          => $f['id'],
        'descripcion' => $f['descripcion'] ?? '',
        'conductor'   => $f['conductor']   ?? '',
        'paradas'     => array_values(
                            array_filter(explode('|', $f['paradas'] ?? ''))
                         ),
        'camino'      => $coords,
        'dOrig'       => (int)round($o['dist']),
        'iOrig'       => $o['idx'],
        'dDest'       => (int)round($d['dist']),
        'iDest'       => $d['idx'],
    ];
}

// Transbordo = mitad del radio elegido por el usuario
$radioTransbordo = (int)($radio * 0.5);

/* ──────────────────────────────────────────
   PASO 1 — RUTA DIRECTA
   (sin chequeo de dirección de índice)
────────────────────────────────────────── */
$directas = array_filter($rutas, fn($r) =>
    $r['dOrig'] <= $radio &&
    $r['dDest'] <= $radio
);

if ($directas) {
    usort($directas, fn($a, $b) =>
        ($a['dOrig'] + $a['dDest']) - ($b['dOrig'] + $b['dDest'])
    );
    $r = array_values($directas)[0];

    echo json_encode([
        'tipo'  => 'directo',
        'pasos' => [[
            'tipo'        => 'ruta',
            'numero'      => 1,
            'nombre'      => $r['nombre'],
            'descripcion' => $r['descripcion'],
            'conductor'   => $r['conductor'],
            'paradas'     => $r['paradas'],
            'camino'      => $r['camino'],
            'dist_orig'   => $r['dOrig'],
            'dist_dest'   => $r['dDest'],
            'instruccion' => "Aborda la ruta <strong>{$r['nombre']}</strong> "
                           . "a ~{$r['dOrig']} m de tu ubicación. "
                           . "Bájate al llegar a ~{$r['dDest']} m de tu destino.",
        ]]
    ]);
    exit;
}

/* ──────────────────────────────────────────
   PASO 2 — 1 TRANSBORDO (2 rutas)
────────────────────────────────────────── */
$desdeOrigen  = array_values(array_filter($rutas, fn($r) => $r['dOrig'] <= $radio));
$hastaDestino = array_values(array_filter($rutas, fn($r) => $r['dDest'] <= $radio));

$mejorPlan  = null;
$mejorScore = PHP_FLOAT_MAX;

foreach ($desdeOrigen as $rA) {
    foreach ($hastaDestino as $rB) {
        if ($rA['nombre'] === $rB['nombre']) continue;

        $minTrans  = PHP_FLOAT_MAX;
        $ptTrans   = null;
        $idxTransB = 0;

        // Buscar transbordo en todos los puntos de rA (sin restricción de índice)
        foreach ($rA['camino'] as $iA => $pA) {
            $tb = distMinRuta($pA['lat'], $pA['lng'], $rB['camino']);
            if ($tb['dist'] < $minTrans) {
                $minTrans  = $tb['dist'];
                $ptTrans   = $pA;
                $idxTransB = $tb['idx'];
            }
        }

        if ($minTrans > $radioTransbordo) continue;

        $score = $rA['dOrig'] + $minTrans + $rB['dDest'];

        if ($score < $mejorScore) {
            $mejorScore = $score;
            $mejorPlan  = [
                'tipo'  => 'transbordo_1',
                'pasos' => [
                    [
                        'tipo'        => 'ruta',
                        'numero'      => 1,
                        'nombre'      => $rA['nombre'],
                        'descripcion' => $rA['descripcion'],
                        'conductor'   => $rA['conductor'],
                        'paradas'     => $rA['paradas'],
                        'camino'      => $rA['camino'],
                        'dist_orig'   => $rA['dOrig'],
                        'dist_dest'   => null,
                        'instruccion' => "Aborda la ruta <strong>{$rA['nombre']}</strong> "
                                       . "a ~{$rA['dOrig']} m de tu ubicación.",
                    ],
                    [
                        'tipo'          => 'transbordo',
                        'numero'        => 0,
                        'dist_caminata' => (int)round($minTrans),
                        'punto'         => $ptTrans,
                        'instruccion'   => "Bájate y camina ~"
                                         . (int)round($minTrans)
                                         . " m hasta la siguiente ruta.",
                    ],
                    [
                        'tipo'        => 'ruta',
                        'numero'      => 2,
                        'nombre'      => $rB['nombre'],
                        'descripcion' => $rB['descripcion'],
                        'conductor'   => $rB['conductor'],
                        'paradas'     => $rB['paradas'],
                        'camino'      => $rB['camino'],
                        'dist_orig'   => null,
                        'dist_dest'   => $rB['dDest'],
                        'instruccion' => "Aborda la ruta <strong>{$rB['nombre']}</strong> "
                                       . "y bájate a ~{$rB['dDest']} m de tu destino.",
                    ],
                ]
            ];
        }
    }
}

if ($mejorPlan) { echo json_encode($mejorPlan); exit; }

/* ──────────────────────────────────────────
   PASO 3 — 2 TRANSBORDOS (3 rutas)
────────────────────────────────────────── */
foreach ($desdeOrigen as $rA) {
    foreach ($rutas as $rM) {
        if ($rM['nombre'] === $rA['nombre']) continue;

        // Transbordo A → M
        $minTransAM = PHP_FLOAT_MAX;
        $ptTransAM  = null;
        $iTransM    = 0;

        foreach ($rA['camino'] as $iA => $pA) {
            $tb = distMinRuta($pA['lat'], $pA['lng'], $rM['camino']);
            if ($tb['dist'] < $minTransAM) {
                $minTransAM = $tb['dist'];
                $ptTransAM  = $pA;
                $iTransM    = $tb['idx'];
            }
        }
        if ($minTransAM > $radioTransbordo) continue;

        foreach ($hastaDestino as $rB) {
            if ($rB['nombre'] === $rA['nombre'] ||
                $rB['nombre'] === $rM['nombre']) continue;

            // Transbordo M → B
            $minTransMB = PHP_FLOAT_MAX;
            $ptTransMB  = null;

            foreach ($rM['camino'] as $iM2 => $pM) {
                if ($iM2 < $iTransM) continue;
                $tb2 = distMinRuta($pM['lat'], $pM['lng'], $rB['camino']);
                if ($tb2['dist'] < $minTransMB) {
                    $minTransMB = $tb2['dist'];
                    $ptTransMB  = $pM;
                }
            }
            if ($minTransMB > $radioTransbordo) continue;

            $score = $rA['dOrig'] + $minTransAM + $minTransMB + $rB['dDest'];

            if ($score < $mejorScore) {
                $mejorScore = $score;
                $mejorPlan  = [
                    'tipo'  => 'transbordo_2',
                    'pasos' => [
                        [
                            'tipo'        => 'ruta',
                            'numero'      => 1,
                            'nombre'      => $rA['nombre'],
                            'descripcion' => $rA['descripcion'],
                            'conductor'   => $rA['conductor'],
                            'paradas'     => $rA['paradas'],
                            'camino'      => $rA['camino'],
                            'dist_orig'   => $rA['dOrig'],
                            'dist_dest'   => null,
                            'instruccion' => "Aborda la ruta <strong>{$rA['nombre']}</strong> "
                                           . "a ~{$rA['dOrig']} m de tu ubicación.",
                        ],
                        [
                            'tipo'          => 'transbordo',
                            'numero'        => 0,
                            'dist_caminata' => (int)round($minTransAM),
                            'punto'         => $ptTransAM,
                            'instruccion'   => "Bájate y camina ~"
                                             . (int)round($minTransAM)
                                             . " m al siguiente autobús.",
                        ],
                        [
                            'tipo'        => 'ruta',
                            'numero'      => 2,
                            'nombre'      => $rM['nombre'],
                            'descripcion' => $rM['descripcion'],
                            'conductor'   => $rM['conductor'],
                            'paradas'     => $rM['paradas'],
                            'camino'      => $rM['camino'],
                            'dist_orig'   => null,
                            'dist_dest'   => null,
                            'instruccion' => "Aborda la ruta <strong>{$rM['nombre']}</strong> "
                                           . "(ruta intermedia).",
                        ],
                        [
                            'tipo'          => 'transbordo',
                            'numero'        => 0,
                            'dist_caminata' => (int)round($minTransMB),
                            'punto'         => $ptTransMB,
                            'instruccion'   => "Bájate y camina ~"
                                             . (int)round($minTransMB)
                                             . " m al siguiente autobús.",
                        ],
                        [
                            'tipo'        => 'ruta',
                            'numero'      => 3,
                            'nombre'      => $rB['nombre'],
                            'descripcion' => $rB['descripcion'],
                            'conductor'   => $rB['conductor'],
                            'paradas'     => $rB['paradas'],
                            'camino'      => $rB['camino'],
                            'dist_orig'   => null,
                            'dist_dest'   => $rB['dDest'],
                            'instruccion' => "Aborda la ruta <strong>{$rB['nombre']}</strong> "
                                           . "y bájate a ~{$rB['dDest']} m de tu destino.",
                        ],
                    ]
                ];
            }
        }
    }
}

if ($mejorPlan) { echo json_encode($mejorPlan); exit; }

/* ──────────────────────────────────────────
   SIN RESULTADO
────────────────────────────────────────── */
echo json_encode([
    'tipo'  => 'sin_ruta',
    'error' => 'No encontramos rutas trazadas que conecten tu ubicación '
             . 'con ese destino. Intenta aumentar el radio o elige un '
             . 'destino dentro de Culiacán.'
]);